1. Unzip
2. Upload all files and folders to GitHub repo root
3. Enable GitHub Pages from main branch > root folder
4. Done!